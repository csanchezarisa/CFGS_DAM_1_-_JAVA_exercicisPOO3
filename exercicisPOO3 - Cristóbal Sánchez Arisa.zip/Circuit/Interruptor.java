package Circuit;

public class Interruptor {

    public static void modificarEstatBombeta(Bombeta bombeta) {
        bombeta.setEstatBombeta(!(bombeta.getEstatBombeta()));
    }

}
