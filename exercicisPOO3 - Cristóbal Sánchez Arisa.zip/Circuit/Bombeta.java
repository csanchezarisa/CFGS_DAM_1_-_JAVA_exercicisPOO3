package Circuit;

public class Bombeta {

    private boolean estatBombeta;

    public boolean getEstatBombeta() {
        return this.estatBombeta;
    }

    public void setEstatBombeta(boolean estat) {
        this.estatBombeta = estat;
    }

}
